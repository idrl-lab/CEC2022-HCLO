# -*- encoding: utf-8 -*-
"""
@File    :   example.py
@Time    :   2022/02/20 17:07:07
@Author  :   Xianqi
@Contact :   chenxianqi12@qq.com
"""


import numpy as np


def tournamentSelection(K, N, fitness):
    parents = np.random.randint(len(fitness), size=(K, N))
    best = np.argmin(fitness.reshape(-1)[parents.reshape(-1)].reshape(K, N), axis=0)
    index = parents.reshape(-1)[np.arange(N) + best * N]
    return index


def main_algorithm(totalFes, domain, component, heatpipe, getObjCons):
    """
    The example algorithm for illustrating the format

    Args:
        totalFes: the maximum number of function evaluations
        domain: parameter from Problem definition
        component: parameter from Problem definition
        heatpipe: parameter from Problem definition
        getObjCons: function name from utils module

    Returns:
        bestSolution: the best feasible solution
        iter_best_sol: the iteration history of the best solution
        iter_best_val: the iteration history of the best objective value
    """
    # parameter settings
    n_p = 60  # the size of population
    rang_l = np.tile(component.x_opt_min, (n_p, 1))
    rang_r = np.tile(component.x_opt_max, (n_p, 1))
    n_d = component.x_opt_dim  # the number of variables

    # Example
    popu = np.random.uniform(rang_l, rang_r, (n_p, n_d))
    objF = np.zeros((n_p, 1))
    conV = np.zeros((n_p, 1))
    for i in range(n_p):
        objective, constraint = getObjCons(popu[i, :], domain, component, heatpipe)
        obj = objective[0]
        cons1, cons2, cons3, cons4 = constraint
        objF[i, 0] = obj
        conV[i, 0] = np.sum(constraint)
    fitness = objF + conV * 1e6

    index = tournamentSelection(2, n_p, fitness)
    Parent_dec = popu[index, :]
    ParentDec = np.vstack(Parent_dec, Parent_dec[0, :]) if n_p % 2 > 0 else Parent_dec

    N, D = ParentDec.shape
    proC = 1
    disC = 20
    proM = 1
    disM = 20
    fitcount = n_p
    iteration = 1
    halfN = int(N / 2)
    iter_best_val = []
    iter_best_sol = []

    while fitcount <= totalFes:
        print("iteration = ", iteration)
        Parent1Dec = ParentDec[0:halfN, :]
        Parent2Dec = ParentDec[halfN:N, :]

        # Simulated binary crossover
        beta = np.zeros((halfN, D))
        mu = np.random.rand(halfN, D)
        beta[mu <= 0.5] = (2 * mu[mu <= 0.5]) ** (1 / (disC + 1))
        beta[mu > 0.5] = (2 - 2 * mu[mu > 0.5]) ** (-1 / (disC + 1))
        beta = beta * (-1) ** (np.random.randint(2, size=(halfN, D)))
        beta[np.random.rand(halfN, D) < 0.5] = 1
        beta[np.tile(np.random.rand(halfN, 1), (1, D)) > proC] = 1
        offSpringDec1 = (Parent1Dec + Parent2Dec) / 2 + beta * (
            Parent1Dec - Parent2Dec
        ) / 2
        offSpringDec2 = (Parent1Dec + Parent2Dec) / 2 - beta * (
            Parent1Dec - Parent2Dec
        ) / 2
        offSpringDec = np.vstack((offSpringDec1, offSpringDec2))

        # Polynomial mutation
        lower = np.tile(component.x_opt_min, (N, 1))
        upper = np.tile(component.x_opt_max, (N, 1))
        site1 = np.random.rand(N, D) < proM / D
        mu = np.random.rand(N, D)
        temp = site1 & (mu <= 0.5)
        offSpringDec[temp] = offSpringDec[temp] + (upper[temp] - lower[temp]) * (
            (
                2 * mu[temp]
                + (1 - 2 * mu[temp])
                * (1 - (offSpringDec[temp] - lower[temp]) / (upper[temp] - lower[temp]))
                ** (disM + 1)
            )
            ** (1 / (disM + 1))
            - 1
        )
        temp = site1 & (mu > 0.5)
        offSpringDec[temp] = offSpringDec[temp] + (upper[temp] - lower[temp]) * (
            1 - (
                2 * (1 - mu[temp])
                + 2 * (mu[temp] - 0.5)
                * (1 - (upper[temp] - offSpringDec[temp]) / (upper[temp] - lower[temp]))
                ** (disM + 1)
            )
            ** (1 / (disM + 1))
        )

        offSpringDec = np.maximum(np.minimum(offSpringDec, upper), lower)

        for i in range(N):
            objective, constraint = getObjCons(popu[i, :], domain, component, heatpipe)
            objF1 = objective[0]
            cons1, cons2, cons3, cons4 = constraint
            conV1 = np.sum(constraint)
            fit_val = objF1 + 1e6 * conV1

            fitcount += 1
            if fit_val < fitness[i, 0]:
                popu[i, :] = offSpringDec[i, :]
                fitness[i, 0] = fit_val
                objF[i, 0] = objF1
                conV[i, 0] = conV1

        index = tournamentSelection(2, N, fitness)
        ParentDec = popu[index, :]

        # record the best solution
        feasiIndex = np.where(conV.reshape(-1) == 0)[0]
        if len(feasiIndex) > 0:
            # sort the feasible solutions according to their objective
            # function values
            sortedObjF = np.sort(objF.reshape(-1)[feasiIndex])
            index_sortedObjF = np.argsort(objF.reshape(-1)[feasiIndex])
            
            # the best solution is the feasible solution with minimum 
            # objective function value
            bestvalue = sortedObjF[0]
            bestSolution = popu[feasiIndex[index_sortedObjF[0]], :]
        else:
            # if the population is infeasbile, the best solution is assigned
            # the value of Inf
            bestvalue = np.Inf
            index_conV = np.argsort(conV.reshape(-1))
            bestSolution = popu[index_conV[0], :]
        
        iter_best_val.append(bestvalue)
        iter_best_sol.append(bestSolution)
        iteration += 1
    
    return (bestSolution, iter_best_sol, iter_best_val)
