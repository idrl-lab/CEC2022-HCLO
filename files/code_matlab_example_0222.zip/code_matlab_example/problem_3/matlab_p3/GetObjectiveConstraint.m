function [obj, cons1, cons2, cons3, cons4] = GetObjectiveConstraint(x_opt, domain, component, heatpipe)
% Calculate values of the objective and constraints
% Input: 
%   x_opt - design variables
% Ouput��
%   [obj, cons1, cons2, cons3, cons4]
% obj: the maximal real heat dissipation power of all heat pipes
% cons1: non-overlapping constraint - overlap volume
% cons2: system centroid deviation constraint - deviation volume
% cons3: maximal heat dissipation capacity constraint - violation volume
% cons4: overlapping constraint between components and heat pipes -
%        violation volume

x = Interpreter(x_opt, component);

% objective 
[hep_power, comp_hep_dis] = Fun3_heatpower(x, heatpipe, component);

obj = max(hep_power(1, :)) + max(hep_power(2, :));  % the maximal heat dissipation power of heat pipes

% constraint 1
overlap = Fun1_overlap(x, domain, component);
cons1 = overlap;

% constraint 2
yc = Fun2_systemcentroid(x, component);
yc_ex = 20;
dyc_eps = 5;
cons2 = max([abs(yc - yc_ex) - dyc_eps, 0]);

% constraint 3
hep_maxload = heatpipe.maxload;
cons3 = sum(hep_power(hep_power > hep_maxload) - hep_maxload);  % = 0

% constraint 4
cons4 = sum(comp_hep_dis);
