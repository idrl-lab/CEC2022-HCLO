function overlap = Fun1_overlap(x, domain, component)

component_position = reshape(x, 2, [])';

num1 = component.num_plane(1);
dom_sub1 = [domain.sub1.location, domain.sub1.angle, ones(4, 1)];  
dom_sub1_size = [domain.sub1.size, ones(4, 1)];

com_sub1 = [component_position(1:num1, :), component.angle(1:num1, :), ones(num1, 1)];
com_sub1_size = [component.size(1:num1, :), ones(num1, 1)];

Comp_sub1 = [dom_sub1; com_sub1];
Comp_sub1_size = [dom_sub1_size; com_sub1_size];
distance1 = PhiFun_Comps1_Comps2(Comp_sub1, Comp_sub1_size);
distance1 = min(distance1, 0);

overlap = - sum(distance1(:)) / 2;  % overlap > 0 means that there exists overlap. 


