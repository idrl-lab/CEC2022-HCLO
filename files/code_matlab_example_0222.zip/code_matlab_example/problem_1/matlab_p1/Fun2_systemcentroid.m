function yc = Fun2_systemcentroid(x, component)

obj_mass = component.mass;
y_center = reshape(x, 2, [])'; % n * 2

sy = sum(obj_mass .* y_center(:, 2));
yc = sy / sum(obj_mass);

   


