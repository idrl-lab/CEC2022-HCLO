%% Test Example of calling function: GetObjectiveConstraint 
[domain, component, heatpipe] = ProblemParameters();

% The bounds for design variables can be obtained by calling
% component.x_min : lower bound
% component.x_max : upper bound
dim = size(component.x_min, 2);
x_test = rand(1, dim) .* (component.x_max - component.x_min) + component.x_min;

%% get objective and constraints for problem 1
[obj, cons1, cons2, cons3, cons4] = GetObjectiveConstraint(x_test, domain, component, heatpipe);

% Objective should be minmized.
% Constraint violations should be equal to zero. 
% Constraint violation definition: G(x) = max([g(x), 0])
disp(['Minimizing Obj = ', num2str(obj)]);
disp(['Cons1 Violation = ', num2str(cons1)]);
disp(['Cons2 Violation = ', num2str(cons2)]);
disp(['Cons3 Violation = ', num2str(cons3)]);
disp(['Cons4 Violation = ', num2str(cons4)]);
%% draw the layout scheme
Plot_layout(x_test);
