function Distance = PhiFun_Comps1_Comps2(Comps1, Comps1Size, Comps2, Comps2Size)
% Calculate the distance matrix between Comps1 and Comps2.
% Input: 
%       Comps1, Comps2: M * 4, N * 4 (x,y,theta,flag)
%                       flag = 0 mean circles
%                       flag = 1 mean rectangles
%       Comps1Size, Comps2Size: (width, height)
% Output:
%       Distance M * N

M = size(Comps1,1);
if nargin < 4
    N = M;
    Comps2 = Comps1;
    Comps2Size = Comps1Size;
    ind1 = (M-1);
else
    N = size(Comps2, 1);
    ind1 = M;
end

Distance = zeros(M,N);

for i = 1:ind1
    u1 = Comps1(i,1:3);
    if nargin < 4
        ind2 = i + 1;
    else
        ind2 = 1;
    end
    len = N - ind2 + 1;
    
    u1 = repmat(u1, len, 1);
    u2 = Comps2(ind2:N, 1:3);
    
    a1 = repmat(Comps1Size(i, 1)/2, len, 1);
    b1 = repmat(Comps1Size(i, 2)/2, len, 1);
    a2 = Comps2Size(ind2 : N, 1)/2;
    b2 = Comps2Size(ind2 : N, 2)/2;
    Distance(i, ind2:N) = PhiFunFixed_RR(u1,a1,b1,u2,a2,b2)';
end

if nargin < 4
    Distance = Distance + Distance';
end

end
%%
function Phi = PhiFunFixed_RR(u1,a1,b1,u2,a2,b2)
% Function: to calculate the value of Phi-function for two rectangles
%    If the value of Phi is over than zero, it means two Rec are separated.
%    If the value of Phi is right zero, it means two Rec touch.
%    If the value of Phi is less than zeros, it means two Rec intersect.
% Input variables: the parameters of two rectangles
% u1 = (x1,y1) - the center of Rec 1
% (a1,b1) - the half-side of Rec 1 - A half of length or width 
% u2 = (x2,y2) - the center of Rec 2
% (a2,b2) - the half-side of Rec 2
% Output: the value of Phi-function

% Equation: Phi_RR = max{(|x1 - x2| - a1 - a2), (|y1 - y2| - b1 - b2)}.
% REMARK : in numerical implementation of this and other formulas, the
% absolute value function is not used, as it makes the application of the
% gradient optimization method difficult. Instead, we use minimum or
% maximum . For example, we compute |x1 - x2| = max{x1 - x2, x2 - x1}.
x1 = u1(:, 1); y1 = u1(:, 2);
x2 = u2(:, 1); y2 = u2(:, 2);

Phi1 = abs(x1 - x2) - a1 - a2;
Phi2 = abs(y1 - y2) - b1 - b2;
Phi12 = [Phi1, Phi2];
Phi = max(Phi12, [], 2);  % N * 1

end




