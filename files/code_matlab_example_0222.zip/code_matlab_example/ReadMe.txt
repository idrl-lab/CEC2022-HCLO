This file includes two matlab scripts:

- main_test.m: the main function for testing algorithms proposed by participants.
  - Ensure that this file can be rightly run with the submitted algorithm.
- example.m: one GA example for participants preparing the algorithm code. It should clearly illustrate the main function of running the algorithm. 
  - The input of this main function should contain the maximum number of function evaluations. 
  - This function should return the obtained best feasible solution, as well as the iteration histories of the best solution and the best feasible objective value. 
  - The other subfunctions should be included in the same folder.

-------------------------------------------------------------------------------------
% Algorithm function example
[Bestsolution,iter_best_sol,iter_best_val] = example(totalFes,domain, component, heatpipe)

% The example algorithm for illustrating the format.
% 'example': your algorithm function name
% 
% Args:
%     totalFes: the maximum number of function evaluations
%     domain: parameter from Problem definition
%     component: parameter from Problem definition
%     heatpipe: parameter from Problem definition
% 
% Returns:
%     Bestsolution: the best feasible solution
%     iter_best_sol: the iteration history of the best solution
%     iter_best_val: the iteration history of the best objective value

% Your algorithm starts here.
% ......
% Your algorithm ends here.
end
-------------------------------------------------------------------------------------

If you have further questions, please do not hesitate to contact us by Email (chenxianqi12@nudt.edu.cn).