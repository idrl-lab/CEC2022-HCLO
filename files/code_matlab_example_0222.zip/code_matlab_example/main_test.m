
% This function is written by Zhenshou Song
% If you have further questions, please do not hesitate to contact us by Email
% zssong@stu.xidian.edu.cn or other organizers

clear;
clc;
warning off

currentFolder = pwd;
for problem = [1, 2, 3, 4]
    rmpath('problem_1\matlab_p1', ...
        'problem_2\matlab_p2', ...
        'problem_3\matlab_p3', ...
        'problem_4\matlab_p4');
    switch problem     % switch the test problem
        case 1
            addpath('problem_1\matlab_p1');
        case 2
            addpath('problem_2\matlab_p2');
        case 3
            addpath('problem_3\matlab_p3');
        case 4
            addpath('problem_4\matlab_p4');
    end

    [domain, component, heatpipe] = ProblemParameters();
    D = size(component.x_min, 2);  % Obtain the number of variables
    runtimes = 30; 
    totalFes = 5000*D;  % Set the maximum number of function evaluations
    algorithms = {'example'}; % Set the test algorithm

    for alg = 1:1
        algorithm = algorithms{alg};
        for run = 1: runtimes
            % The outputs should record the best solution and the corresponding
            % fitness value in each iteration
           [Bestsolution,iter_best_sol,iter_best_val] = feval(algorithm,totalFes,domain, component, heatpipe);
        end
    end

end
