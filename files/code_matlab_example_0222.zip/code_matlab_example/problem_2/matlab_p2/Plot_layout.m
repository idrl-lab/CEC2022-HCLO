function Plot_layout(x)
component_position = reshape(x, 2, [])';

[domain, component, heatpipe] = ProblemParameters();

%% ���������ͼ
fh1 = figure;
hold on;
% axis equal;
box on;
margin = 5;
% axis([domain.location(1, 1) - margin, domain.location(1, 3) + margin, domain.location(1, 4) - margin, domain.location(1, 2)  + margin]);

%% draw the layout domain
width1 = domain.location(1,3) - domain.location(1, 1);
height1 = domain.location(1,2) - domain.location(1, 4);
width2 = domain.location(2,3) - domain.location(2, 1);
height2 = domain.location(2,4) - domain.location(2, 2);
dom_left_dw_pos = [domain.location(1, 1), domain.location(1, 4), width1, height1];
dom_left_up_pos = [domain.location(2, 1:2), width2, height2];

rectangle('Position',dom_left_dw_pos,'FaceColor','none','EdgeColor','r');
rectangle('Position',dom_left_up_pos,'FaceColor','none','EdgeColor','r');


%% draw components
num1 = sum(component.num_plane(1:2));
com_left_loc = component_position(1:num1, :) - component.size(1:num1, :) / 2;
com_left_size = component.size(1:num1, :);
com_left_pos = [com_left_loc, com_left_size];

for i = 1:num1
    rectangle('Position',com_left_pos(i, :),'FaceColor','none','EdgeColor','b');
    text(com_left_loc(i,1),component_position(i,2), num2str(i));
end
%% draw heatpipes
hep_num = heatpipe.number;
hep_loc = heatpipe.position - repmat(heatpipe.size, hep_num, 1) / 2;
hep_pos = [hep_loc, repmat(heatpipe.size, hep_num, 1)];
for i = 1:hep_num
    rectangle('Position',hep_pos(i, :),'FaceColor','none','EdgeColor','g', 'LineStyle', '--', 'LineWidth', 0.5);
end

%%
if component.num_plane(2) == 0
    axis([domain.location(1, 1) - margin, domain.location(1, 3) + margin, domain.location(1, 4) - margin, domain.location(1, 2)  + margin]);
elseif component.num_plane(1) == 0
    axis([domain.location(2, 1) - margin, domain.location(2, 3) + margin, domain.location(2, 2) - margin, domain.location(2, 4)  + margin]);
else
    axis([domain.location(1, 1) - margin, domain.location(1, 3) + margin, domain.location(1, 4) - margin, domain.location(1, 2)  + margin]);
end

%%
hold off;

% set(fh1,'position',[10,50,520,450]);
% set(gca,'position',[0.035,0.05,0.99,0.93]);
% print(fh1,['Random_layout'],'-djpeg','-r300')
