function [Bestsolution,iter_best_sol,iter_best_val] = example(totalFes,domain, component, heatpipe)
% The example algorithm for illustrating the format.
% 'example': your algorithm function name
% 
% Args:
%     totalFes: the maximum number of function evaluations
%     domain: parameter from Problem definition
%     component: parameter from Problem definition
%     heatpipe: parameter from Problem definition
% 
% Returns:
%     Bestsolution: the best feasible solution
%     iter_best_sol: the iteration history of the best solution
%     iter_best_val: the iteration history of the best objective value

%% common parameter settings
rang_l =  component.x_min;
rang_r =  component.x_max;
n_d = size(component.x_min, 2);


%% Example
n_p = 60;
popu= rang_l + (rang_r - rang_l) .* rand(n_p,n_d); 
for i = 1: n_p
    [obj, cons1, cons2, cons3, cons4] = GetObjectiveConstraint(popu(i,:), domain, component, heatpipe); % function evaluation
    objF(i,1) = obj;
    g = [cons1, cons2, cons3, cons4];
    term = max(0, g);
    conV(i,1) = sum(term, 2);
end
fitness = objF + conV*10e6;

index = TournamentSelection(2,n_p,fitness);
Parent_dec    = popu(index,:);
ParentDec = Parent_dec([1:end,1:ceil(end/2)*2-end],:);
[N,D] = size(ParentDec);
proC = 1;
disC = 20;
proM = 1;
disM = 20;
fitcount = n_p;
iter = 1;
while  fitcount <= totalFes
    disp(iter)
Parent1Dec = ParentDec(1:N/2,:);
Parent2Dec = ParentDec(N/2+1:end,:);
%% Simulated binary crossover
beta = zeros(N/2,D);
mu   = rand(N/2,D);
beta(mu<=0.5) = (2*mu(mu<=0.5)).^(1/(disC+1));
beta(mu>0.5)  = (2-2*mu(mu>0.5)).^(-1/(disC+1));
beta = beta.*(-1).^randi([0,1],N/2,D);
beta(rand(N/2,D)<0.5) = 1;
beta(repmat(rand(N/2,1)>proC,1,D)) = 1;
OffspringDec = [(Parent1Dec+Parent2Dec)/2+beta.*(Parent1Dec-Parent2Dec)/2
    (Parent1Dec+Parent2Dec)/2-beta.*(Parent1Dec-Parent2Dec)/2];
% Polynomial mutation
Lower = repmat(rang_l,N,1);
Upper = repmat(rang_r,N,1);
Site = rand(N,D) < proM/D;
mu    = rand(N,D);
temp  = Site & mu<=0.5;
OffspringDec(temp) = OffspringDec(temp)+(Upper(temp)-Lower(temp)).*((2.*mu(temp)+(1-2.*mu(temp)).*...
    (1-(OffspringDec(temp)-Lower(temp))./(Upper(temp)-Lower(temp))).^(disM+1)).^(1/(disM+1))-1);
temp = Site & mu>0.5;
OffspringDec(temp) = OffspringDec(temp)+(Upper(temp)-Lower(temp)).*(1-(2.*(1-mu(temp))+2.*(mu(temp)-0.5).*...
    (1-(Upper(temp)-OffspringDec(temp))./(Upper(temp)-Lower(temp))).^(disM+1)).^(1/(disM+1)));

  OffspringDec  = max(min(OffspringDec,Upper),Lower);
  
  for i = 1: size(OffspringDec,1)
    [obj, cons1, cons2, cons3, cons4] = GetObjectiveConstraint(OffspringDec(i,:), domain, component, heatpipe); % function evaluation
    objF1= obj;
    g = [cons1, cons2, cons3, cons4];
    term = max(0, g);
    conV1 = sum(term, 2);
    fit_val =  objF1 + conV1*10e6;
      fitcount = fitcount+1;
      if fit_val < fitness(i)
          popu(i,:) = OffspringDec(i,:);
          fitness(i,1) = fit_val;
          conV(i,:) = conV1;
          objF(i,:) = objF1;
      end
  end
  
  index = TournamentSelection(2,n_p,fitness);
  Parent_dec    = popu(index,:);
  ParentDec = Parent_dec([1:end,1:ceil(end/2)*2-end],:);
  
  %% record the best solution
  feasiIndex = find(conV == 0); 
  if ~isempty(feasiIndex)

      % sort the feasible solutions according to their objective
      % function values
      [sortedFeasiVec,index_num]=sort(objF(feasiIndex));
      % the best solution is the feasible solution with minimum
      % objective function value
      bestvalue=sortedFeasiVec(1);
      Bestsolution = popu(feasiIndex(index_num(1)),:);
  else
      % if the population is infeasible, the best solution is
      % assigned the value of NaN
      bestvalue=NaN;
      [~,index_num] = min(conV);
      Bestsolution = popu(index_num,:);
  end
  iter_best_val(iter)  = bestvalue;
  iter_best_sol(iter,:)  = Bestsolution;
  iter = iter +1;



end
end

function index = TournamentSelection(K,N,fitness)
    [~,rank] = sortrows(fitness);
    [~,rank] = sort(rank);
    Parents  = randi(length(rank),K,N);
    [~,best] = min(rank(Parents),[],1);
    index    = Parents(best+(0:N-1)*K);
end
