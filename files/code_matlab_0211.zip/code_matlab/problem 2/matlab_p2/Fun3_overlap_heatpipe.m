function [overlap_left, overlap_right] = Fun3_overlap_heatpipe(x, heatpipe, component, safe_dis)

component_position = reshape(x, 2, [])';
comp_size = component.size - safe_dis;
hep_size_org = heatpipe.size;
hep_size_org(1, 1) = hep_size_org(1, 1) - safe_dis;
%% left panel
num1 = sum(component.num_plane(1:2));
hep_num = heatpipe.number;

hep = [heatpipe.position, zeros(hep_num, 1), ones(hep_num, 1)];
hep_size = [repmat(hep_size_org, hep_num, 1), ones(hep_num, 1)];

com_left = [component_position(1:num1, :), component.angle(1:num1, :), ones(num1, 1)];
com_left_size = [comp_size(1:num1, :), ones(num1, 1)];

distance_left = PhiFun_Comps1_Comps2(hep, hep_size, com_left, com_left_size);

overlap_left = - distance_left;

%% right panel
num2 = sum(component.num_plane(1:4));
com_right = [component_position(num1 + 1:num2, :), component.angle(num1 + 1:num2, :), ones(num2 - num1, 1)];
com_right_size = [comp_size(num1 + 1:num2, :), ones(num2 - num1, 1)];

distance_right = PhiFun_Comps1_Comps2(hep, hep_size, com_right, com_right_size);

overlap_right = - distance_right;
