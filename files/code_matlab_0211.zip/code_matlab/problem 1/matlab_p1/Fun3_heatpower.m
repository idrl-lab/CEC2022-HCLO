function [hep_power, comp_hep_dis] = Fun3_heatpower(x, heatpipe, component)

[overlap_left] = Fun3_overlap_heatpipe(x, heatpipe, component, 0.99*heatpipe.size(1, 1));
overlap_left_dis = Fun3_overlap_heatpipe(x, heatpipe, component, heatpipe.size(1, 1));
%% 
num1 = sum(component.num_plane(1));
comp_left_intensity = component.intensity(1: num1,:);

overlapflag_left = zeros(size(overlap_left));
overlapflag_left(overlap_left > 0) = 1;
comp_in_hep_num = sum(overlapflag_left, 1);

comp_hep_dis_left = zeros(1, num1);
if min(comp_in_hep_num) < 1
    temp = - max(overlap_left_dis, [], 1);
    comp_index_left = (comp_in_hep_num < 1);
    comp_hep_dis_left(1, comp_index_left) = temp(1, comp_index_left);
end

comp_left_intensity_real = comp_left_intensity;
comp_left_intensity_real(comp_in_hep_num > 0, 1) = comp_left_intensity_real(comp_in_hep_num > 0, 1) ./ (comp_in_hep_num(1, comp_in_hep_num > 0)');

hep_power_left_matrix = repmat(comp_left_intensity_real', heatpipe.number, 1) .* overlapflag_left;
hep_power_left = sum(hep_power_left_matrix, 2);

hep_power = hep_power_left';
comp_hep_dis = comp_hep_dis_left';








