function x_com = Interpreter(x_opt, component)
% Tranform x_opt to x_com (sometimes working)
x_com = zeros(1, component.number * 2);
x_com(component.indicator > 0) = x_opt;

com_pos = reshape(x_com, 2, [])';
x_com = reshape(com_pos', 1, []);



