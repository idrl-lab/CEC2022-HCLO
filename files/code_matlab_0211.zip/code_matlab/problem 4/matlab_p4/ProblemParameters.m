function [domain, component, heatpipe] = ProblemParameters()
%% ��Excel�ļ��ж��������������Ϣ

% filename = 'Problem4_component.xlsx';
% sheet = 1;
% xlRange = 'A2:G91';
% matrix = xlsread(filename, sheet, xlRange);
% save('excel_matrix_problem4.mat', 'matrix')

%% load parameters of components
load('excel_matrix_problem4.mat', 'matrix');
%% components information
component.number = size(matrix, 1);
component.size = matrix(:, 2:3);  % (a,b)
component.mass = matrix(:, 4);
component.intensity = matrix(:,5);
component.originalposition = matrix(:, 6:7);
component.plane = [1*ones(22, 1); 2*ones(23, 1); 3*ones(22, 1); 4*ones(23, 1)];  % �����
component.num_plane = [22, 23, 22, 23];
component.angle = zeros(component.number, 1);
%% layout domain
domain.length = 2000;
domain.width = 2000;
domain.location = [
    100, -50, 1900, -950;  % left-down: [xmin, ymax, xmax, ymin]
    100, 50, 1900, 950;  % left-up: [xmin, ymin, xmax, ymax]
    100, -50, 1900, -950;  % right-down: [xmin, ymax, xmax, ymin]
    100, 50, 1900, 950;  % right-up: [xmin, ymin, xmax, ymax]
];

extend_length = 100;
domain.sub1.location = [
    (domain.location(1, 1) + domain.location(1, 3)) / 2, domain.location(1, 2) + extend_length/2;
    domain.location(1, 1) - extend_length/2, (domain.location(1, 2) + domain.location(1, 4)) / 2;
    (domain.location(1, 1) + domain.location(1, 3)) / 2, domain.location(1, 4) - extend_length/2;
    domain.location(1, 3) + extend_length/2, (domain.location(1, 2) + domain.location(1, 4)) / 2;
];
domain.sub1.size = [
    domain.location(1, 3) - domain.location(1, 1) + 2*extend_length, extend_length;
    extend_length, domain.location(1, 2) - domain.location(1, 4);
    domain.location(1, 3) - domain.location(1, 1) + 2*extend_length, extend_length;
    extend_length, domain.location(1, 2) - domain.location(1, 4);
];
domain.sub1.angle = zeros(4,1);
domain.sub2.location = [
    (domain.location(2, 1) + domain.location(2, 3)) / 2, domain.location(2, 2) - extend_length/2;
    domain.location(2, 1) - extend_length/2, (domain.location(2, 2) + domain.location(2, 4)) / 2;
    (domain.location(2, 1) + domain.location(2, 3)) / 2, domain.location(2, 4) + extend_length/2;
    domain.location(2, 3) + extend_length/2, (domain.location(2, 2) + domain.location(2, 4)) / 2;
];
domain.sub2.size = [
    domain.location(2, 3) - domain.location(2, 1) + 2*extend_length, extend_length;
    extend_length, domain.location(2, 2) - domain.location(2, 4);
    domain.location(2, 3) - domain.location(2, 1) + 2*extend_length, extend_length;
    extend_length, domain.location(2, 2) - domain.location(2, 4);
];
domain.sub2.angle = zeros(4,1);
domain.sub3 = domain.sub2;
domain.sub4 = domain.sub2;
%% heatpipe
heatpipe.number = 16;
heatpipe.interval = 107.647 - 30;
heatpipe.width = 30;
heatpipe.length = domain.width;
heatpipe.size = [heatpipe.width, heatpipe.length];
heatpipe.maxload = 120;
heatpipe.first_position = 192.647;

heatpipe.position = zeros(heatpipe.number, 2);
heatpipe.last_position = heatpipe.first_position + (heatpipe.number - 1) * (heatpipe.width + heatpipe.interval);
posZlist = linspace(heatpipe.first_position, heatpipe.last_position, heatpipe.number);
heatpipe.position(:, 1) = posZlist';

%% design variables
indicator = ones(component.number, 2);
component.indicator = reshape(indicator', 1, []);

%% range of design variables
% ����������ı仯��ΧΪ ��������߽�
component.pos_x_min = [
    domain.location(1, 1) * ones(component.num_plane(1), 1);
    domain.location(2, 1) * ones(component.num_plane(2), 1);
    domain.location(3, 1) * ones(component.num_plane(3), 1);
    domain.location(4, 1) * ones(component.num_plane(4), 1);
];
component.pos_x_max = [
    domain.location(1, 3) * ones(component.num_plane(1), 1);
    domain.location(2, 3) * ones(component.num_plane(2), 1);
    domain.location(3, 3) * ones(component.num_plane(3), 1);
    domain.location(4, 3) * ones(component.num_plane(4), 1);
];
component.pos_y_min = [
    domain.location(1, 4) * ones(component.num_plane(1), 1);
    domain.location(2, 2) * ones(component.num_plane(2), 1);
    domain.location(3, 4) * ones(component.num_plane(3), 1);
    domain.location(4, 2) * ones(component.num_plane(4), 1);
];
component.pos_y_max = [
    domain.location(1, 2) * ones(component.num_plane(1), 1);
    domain.location(2, 4) * ones(component.num_plane(2), 1);
    domain.location(3, 2) * ones(component.num_plane(3), 1);
    domain.location(4, 4) * ones(component.num_plane(4), 1);
];

% ����������ı仯��Χ ��ȥ����ߴ��һ��
component.pos_x_min = component.pos_x_min + component.size(:, 1) / 2;
component.pos_x_max = component.pos_x_max - component.size(:, 1) / 2;
component.pos_y_min = component.pos_y_min + component.size(:, 2) / 2;
component.pos_y_max = component.pos_y_max - component.size(:, 2) / 2;

pos_min = [component.pos_x_min, component.pos_y_min];
pos_max = [component.pos_x_max, component.pos_y_max];
component.x_min_all = reshape(pos_min', 1, []);
component.x_max_all = reshape(pos_max', 1, []);

component.x_min = component.x_min_all(component.indicator > 0);
component.x_max = component.x_max_all(component.indicator > 0);

